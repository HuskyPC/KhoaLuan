﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.Product
{
    public class VMsProductBO
    {
        public String ProductID { get; set; }
        public String name { get; set; }
        public Double price { get; set; }
        public Double priceSale { get; set; }
        public String avatar { get; set; }
        public String urlImage { get; set; }
    }
}

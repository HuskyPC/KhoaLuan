﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.Image
{
    class Image
    {
       public String ImageID { get; set; }
        public String avatar { get; set; }
        public String url { get; set; }
        public int status { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.User
{
    public class GetUserNameBO
    {
        public String userName { get; set; }
    }
}

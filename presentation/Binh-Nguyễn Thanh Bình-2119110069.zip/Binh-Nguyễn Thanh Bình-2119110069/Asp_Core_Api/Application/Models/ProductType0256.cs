﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Application.Models
{
    public partial class ProductType0256
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Alias { get; set; }
        public bool? IsPublic { get; set; }
        public bool? IsTrash { get; set; }
    }
}

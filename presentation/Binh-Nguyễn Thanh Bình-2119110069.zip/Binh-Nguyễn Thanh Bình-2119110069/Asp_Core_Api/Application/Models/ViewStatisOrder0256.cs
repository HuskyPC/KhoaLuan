﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Application.Models
{
    public partial class ViewStatisOrder0256
    {
        public DateTime? CreateDate { get; set; }
        public string StatusName { get; set; }
        public long? Total { get; set; }
    }
}

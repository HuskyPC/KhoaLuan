export const validateRuler = (function(){
	return {}
}());


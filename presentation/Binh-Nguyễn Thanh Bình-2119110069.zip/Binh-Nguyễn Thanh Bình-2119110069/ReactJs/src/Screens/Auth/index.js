import {memo,Fragment} from 'react';
import {Routes,Route,useLocation}from'react-router-dom';
import {getControllerName} from "../../Config/Route/";
function AuthPage(props){
    return (
        <Routes>
            <Route></Route>
        </Routes>
    )
};export default memo(AuthPage)
export const validateRuler = (function(){
	return {
		Name:{
			isRequired:["Vui lòng nhập tên danh mục!"],
			maxLength:[100]
		}
	}
}());


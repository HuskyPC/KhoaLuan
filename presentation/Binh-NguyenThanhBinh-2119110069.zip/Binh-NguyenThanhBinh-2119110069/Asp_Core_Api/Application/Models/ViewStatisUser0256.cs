﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Application.Models
{
    public partial class ViewStatisUser0256
    {
        public DateTime? CreateDate { get; set; }
        public long? Total { get; set; }
    }
}
